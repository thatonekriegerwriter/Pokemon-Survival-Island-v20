module Settings

    #====================================================================================
    #================================= General Settings =================================
    #====================================================================================

        #--------------------------------------------------------------------------------
        # If you place mulch down on a berry spot, but don't actually plant a berry,
        # define which graphic to show on the berry spot. The file should be in
        # Graphics/Characters. Set to "" or nil to not set a graphic.
        #--------------------------------------------------------------------------------	
        BERRY_JUST_MULCH_GRAPHIC            = "berrytreewet"

        #--------------------------------------------------------------------------------
        # [Requires TDW Berry Core and Dex plugin]
        # If a berry is planted and exposed to its preferred weather (as defined in the
        # berry_data.txt PBS file) before reaching its final stage of maturity, add this 
        # many extra berries to its yield. Set to 0 to disable preferred weather.
        #--------------------------------------------------------------------------------	
        BERRY_PREFERRED_WEATHER_YIELD       = 2

    #====================================================================================
    #================================ Mutation Settings =================================
    #====================================================================================
    # Berry mutations occur when a berry plant is next to another berry plant it is
    # compatible with and it produces a rare berry, replacing some of the original 
    # berries the plant would normally produce.
    # https://bulbapedia.bulbagarden.net/wiki/Berry_fields_(Kalos)#Mutation
    
        #--------------------------------------------------------------------------------
        # Switch ID to be set to true for berry mutations to occur.
        # Set to 0 to always allow berry mutations.
        #--------------------------------------------------------------------------------	
        ALLOW_BERRY_MUTATIONS_SWITCH_ID     = 0

        #--------------------------------------------------------------------------------
        # Berry combinations and their mutation possibilities. 
        # The first array is the pair of original berries to be next to each other.
        # The second array is the list of possible berries to be produced as mutations.
        #--------------------------------------------------------------------------------		
        BERRY_MUTATION_POSSIBILITIES        = {
            [:IAPAPABERRY,:MAGOBERRY]   => [:POMEGBERRY],
            [:CHESTOBERRY,:PERSIMBERRY] => [:KELPSYBERRY],
            [:ORANBERRY,:PECHABERRY]    => [:QUALOTBERRY],
            [:ASPEARBERRY,:LEPPABERRY]  => [:HONDEWBERRY],
            [:AGUAVBERRY,:FIGYBERRY]    => [:GREPABERRY],
            [:LUMBERRY,:SITRUSBERRY]    => [:TAMATOBERRY],
            [:HONDEWBERRY,:YACHEBERRY]  => [:LIECHIBERRY],
            [:QUALOTBERRY,:TANGABERRY]  => [:GANLONBERRY],
            [:GREPABERRY,:ROSELIBERRY]  => [:SALACBERRY],
            [:KASIBBERRY,:POMEGBERRY]   => [:PETAYABERRY],
            [:KELPSYBERRY,:WACANBERRY]  => [:APICOTBERRY],
            [:GANLONBERRY,:LIECHIBERRY] => [:KEEBERRY],
            [:PETAYABERRY,:SALACBERRY]  => [:MARANGABERRY]
        }

        #--------------------------------------------------------------------------------
        # List of Mulch items that will impact the chance of berry mutations occuring
        # Format: ITEM_ID => CHANCE
        # ITEM_ID   => Item ID of the Mulch
        # CHANCE    => Chance out of 100 mutated berries will appear when the mulch is 
        #              used
        #--------------------------------------------------------------------------------		
        BERRY_MULCHES_IMPACTING_MUTATIONS    = {
            :SURPRISEMULCH  => 50,
            :AMAZEMULCH     => 50
        }
    
        #--------------------------------------------------------------------------------
        # Base chance out of 100 that berry mutation will occur without mulch influence.
        #--------------------------------------------------------------------------------		
        BERRY_BASE_MUTATION_CHANCE          = 20
    
        #--------------------------------------------------------------------------------
        # If berry mutations occur, how many of the original berries will be replaced by
        # mutations. The number of mutations will never completely overtake the original
        # berries. Examples:
        # - BERRY_MUTATION_COUNT is set to 1, but the plant will only produce 1 berry.
        #   The plant will only produce 1 original berry and no mutated berry.
        # - BERRY_MUTATION_COUNT is set to 2, but the plant will only produce 2 berries.
        #   The plant will produce 1 original berry and 1 mutated berry.
        # - BERRY_MUTATION_COUNT is set to 1, and the plant will produce 5 berries.
        #   The plant will produce 4 original berries and 1 mutated berry.
        #--------------------------------------------------------------------------------		
        BERRY_MUTATION_COUNT                = 1
    
        #--------------------------------------------------------------------------------
        # To give a hint to the player that a plant will produce a mutated berry, set a
        # string that will appear to the player if they interact with the plant while
        # it's in in the blooming stage (stage right before ready to pick).
        # Set to nil if you don't wish to show this comment.
        #
        # For example, when interacting with the blooming plant, it could say:
        #   Original message:   This Oran Berry plant is in bloom! 
        #   Message after:      There is something unique about it...
        #--------------------------------------------------------------------------------	
        BERRY_PLANT_BLOOMING_COMMENT        = _INTL("There is something unique about it...")

        #--------------------------------------------------------------------------------
        # If true, if a berry plant goes through replanting, mutation info will reset,
        # allowing another chance for mutation or losing an existing mutation.
        #--------------------------------------------------------------------------------		
        BERRY_REPLANT_RESETS_MUTATION       = true

    #====================================================================================
    #============================== Propagation Settings ================================
    #====================================================================================
    # Berry propagation can occur when a berry plant replants itself. Instead of just
    # replanting on its own spot, it can also plant one of its berries that "dropped" 
    # in a plantable spot next to it. As far as I know, this is not a mechanic available
    # in mainline Pokemon games.

        #--------------------------------------------------------------------------------
        # Switch ID to be set to true for berry propagations to occur.
        # Set to 0 to always allow berry propagations.
        #--------------------------------------------------------------------------------	
        ALLOW_BERRY_PROPAGATION_SWITCH_ID     = 0

        #--------------------------------------------------------------------------------
        # List of Mulch items that will impact the chance of berry propagation occuring
        # on an empty berry spot nearby. The mulch must be put on the empty spot, not the
        # parent berry plant's spot.
        # Format: ITEM_ID => CHANCE
        # ITEM_ID   => Item ID of the Mulch
        # CHANCE    => Chance out of 1000 berries from nearby replanting plants get
        #              planted on the spot the mulch is.
        #--------------------------------------------------------------------------------		
        BERRY_MULCHES_IMPACTING_PROPAGATION    = {
            :ALLUREMULCH  => 100
        }
    
        #--------------------------------------------------------------------------------
        # Base chance out of 1000 that berry propagation will occur on an empty berry
        # spot when a plant replants itself. Since propagation should be a rare 
        # occurance, it's out of 1000 to allow smaller chances.
        #--------------------------------------------------------------------------------		
        BERRY_BASE_PROPAGATION_CHANCE          = 1

    #====================================================================================
    #================================ Town Map Settings =================================
    #====================================================================================
    # The status of player-planted berries can show up on the Town Map (not when trying
    # to fly or viewing the map on a wall) like you can in BDSP.

        #--------------------------------------------------------------------------------
        # Switch ID to be set to true for berries to appear on the Town Map.
        # Set to 0 to always show.
        #--------------------------------------------------------------------------------	
        SHOW_BERRIES_ON_MAP_SWITCH_ID       = 0

        #--------------------------------------------------------------------------------
        # If true, a specific icon will show if there is a berry in that location that
        # has a moisture level of 0.
        #--------------------------------------------------------------------------------	
        BERRIES_ON_MAP_SHOW_NEED_WATER      = true

        #--------------------------------------------------------------------------------
        # If true, a specific icon will show if there is a berry in that location that
        # is ready to pick. This icon will show instead of the needs water icon if both
        # apply.
        #--------------------------------------------------------------------------------	
        BERRIES_ON_MAP_SHOW_READY           = true

end