Step 1:

Copy the contents of this folder into your game folder (replace any graphics it is asking you to)
If it doesn't ask to replace files you copied the wrong files into the wrong location.


The installation of the script is different depending on whether you have extracted your scripts or not.
Fresh Pokémon Essentials games downloaded from the website don't have scripts extracted.
To see whether your scripts are extracted is to check if there is a 'Scripts' folder in your Data folder.

If you DONT have a Scripts folder (haven't extracted scripts) do the following:

2. Open your game in RPG Maker XP
3. Click on the Scripts button (Paper with the Pen, 2 icons to the left of Play)
4. Copy the Contents of the Script.txt provided into the UI_Party section (Should be somewhat down at the bottom)
5. Hit Apply at the bottom left and hit OK.
6. Done!



If you DO have a Scripts folder (have extracted scripts) do the following:

2. Go to YOURGAME/Data/Scripts/016_UI/
3. Open 007_UI_Party.rb using any text editor (Notepad will do)
4. Copy the Contents of the Script.txt provided into 005_UI_Party.rb and save.
5. Done!