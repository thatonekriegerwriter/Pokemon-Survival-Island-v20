# Triple Triad Booster Pack
This script is for Pokémon Essentials. It's a booster pack item for Triple Triad minigame.

![](Files/BOOSTERPACK.png)
![](Files/STARTERPACK.png)

## Screens
![](Screens/gif.gif)

## Installation
Follow the [Script](/Script.rb) instructions.