# Character Selection
This script is for Pokémon Essentials. It's a character selection screen suggested for player selection or partner selection.

## Screens
![](Screens/gif.gif)
![](Screens/screen.png)

## Installation
Follow the [Script](/Script.rb) instructions. The sample script files are in [Files folder](/Files).