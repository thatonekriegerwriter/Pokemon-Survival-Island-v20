Step 1:

Copy the contents of this folder into your game folder (replace any graphics it is asking you to)
If it doesn't ask to replace files you copied the wrong files into the wrong location.