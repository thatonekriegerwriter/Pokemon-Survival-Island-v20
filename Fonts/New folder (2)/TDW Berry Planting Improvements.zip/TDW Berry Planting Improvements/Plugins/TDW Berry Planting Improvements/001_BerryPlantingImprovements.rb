#===============================================================================
# BerryPlantData
#===============================================================================
class BerryPlantData
    attr_accessor :event
    attr_accessor :town_map_location
    attr_accessor :town_map_checking
    attr_accessor :mutated_berry_tried
    attr_accessor :mutated_berry_info
    attr_accessor :preferred_weather
    attr_accessor :exposed_to_preferred_weather

    alias tdw_berry_plant_init initialize
    def initialize
        tdw_berry_plant_init
        tdw_new_init
    end

    def tdw_new_init
        @event = pbMapInterpreter.get_self
        @town_map_location = nil
        @town_map_location = [$~[1].to_i,$~[2].to_i,$~[3].to_i] if @event.name[/map\((\d+),(\d+),(\d+)\)/i]
        @mutated_berry_tried = false
        @mutated_berry_info = nil
        @exposed_to_preferred_weather = false
    end

    alias tdw_berry_plant_update update
    def update
        tdw_berry_plant_update
        @exposed_to_preferred_weather = true if pbBerryPreferredWeatherEnabled? && checkPreferredWeather
        return if !planted? || !@event || @mutated_berry_tried || @growth_stage < 2 || 
                    (Settings::ALLOW_BERRY_MUTATIONS_SWITCH_ID > 0 && !$game_switches[Settings::ALLOW_BERRY_MUTATIONS_SWITCH_ID])
        checkNearbyPlantsForMutation
    end

    alias tdw_berry_plant_plant plant
    def plant(berry_id)
        tdw_berry_plant_plant(berry_id)
        @preferred_weather = (@berry_id && pbBerryPreferredWeatherEnabled?) ? GameData::BerryData.try_get(@berry_id).preferred_weather : nil
    end

    alias tdw_berry_plant_reset reset
    def reset(planting = false)
        tdw_berry_plant_reset(planting)
        @exposed_to_preferred_weather = false
        @mutated_berry_tried = false
        @mutated_berry_info = nil
    end

    alias tdw_berry_plant_replant replant
    def replant
        propagate if Settings::ALLOW_BERRY_PROPAGATION_SWITCH_ID <= 0 || $game_switches[Settings::ALLOW_BERRY_PROPAGATION_SWITCH_ID]
        tdw_berry_plant_replant
        @exposed_to_preferred_weather = false
        if Settings::BERRY_REPLANT_RESETS_MUTATION
            @mutated_berry_tried = false
            @mutated_berry_info = nil
        end
    end

    alias tdw_berry_plant_water water
    def water
        return if @town_map_checking
        tdw_berry_plant_water
    end

    alias tdw_berry_plant_berry_yield berry_yield
    def berry_yield
        ret = tdw_berry_plant_berry_yield
        ret += 2 if @mulch_id == :RICHMULCH
        ret += Settings::BERRY_PREFERRED_WEATHER_YIELD if @exposed_to_preferred_weather
        return ret
    end

    def propagate
        return if !@event
        propagation = []
        berry = @berry_id
        qty = berry_yield
        qty.times { propagation.push(berry) }
        if @mutation_info
            mut_berry = @mutation_info[0] 
            mut_berry_qty = @mutation_info[1]
            mut_berry_qty -= 1 while qty - mut_berry_qty < 1
            mut_berry_qty.times { propagation.push(mut_berry) }
        end
        checkNearbyPlantsForPropagation(propagation)
    end

    def pbGetNeighbors(position_array = nil, map = nil)
        position = position_array || [@event.map_id, @event.x, @event.y]
        map = map || $map_factory.getMap(position[0])
        neighbors = []
        neighbors[0] = $PokemonGlobal.eventvars[[position[0],map.check_event(position[1], position[2]-1)]]
        neighbors[1] = $PokemonGlobal.eventvars[[position[0],map.check_event(position[1]+1, position[2])]]
        neighbors[2] = $PokemonGlobal.eventvars[[position[0],map.check_event(position[1], position[2]+1)]]
        neighbors[3] = $PokemonGlobal.eventvars[[position[0],map.check_event(position[1]-1, position[2])]]
        return neighbors
    end

    def checkNearbyPlantsForMutation
        $PokemonGlobal.compilePlantMutationParents if !$PokemonGlobal.berry_plant_mutation_parents
        @mutated_berry_tried = true
        return if !@event || !$PokemonGlobal.berry_plant_mutation_parents.include?(@berry_id)
        mutation_chance = Settings::BERRY_MULCHES_IMPACTING_MUTATIONS[@mulch_id] || Settings::BERRY_BASE_MUTATION_CHANCE
        return if mutation_chance <= 0 || rand(100) >= mutation_chance
        #position = [@event.map_id, @event.x, @event.y]
        #map = $map_factory.getMap(position[0])
        neighbors = pbGetNeighbors
        possible = []
        neighbors.each do |data|
            next if data.nil? || !data.is_a?(BerryPlantData) || !data.planted?
            id = data.berry_id
            if Settings::BERRY_MUTATION_POSSIBILITIES[[@berry_id,id]]
                possible.concat(Settings::BERRY_MUTATION_POSSIBILITIES[[@berry_id,id]])
            elsif Settings::BERRY_MUTATION_POSSIBILITIES[[id,@berry_id]]
                possible.concat(Settings::BERRY_MUTATION_POSSIBILITIES[[id,@berry_id]])
            end
        end
        @mutated_berry_info = [possible.sample,Settings::BERRY_MUTATION_COUNT] if possible.length > 0
    end

    def checkNearbyPlantsForPropagation(dropped_berries)
        return if dropped_berries.nil? || dropped_berries.empty?
        neighbors = pbGetNeighbors
        neighbors.each do |data|
            next if data.nil? || !data.is_a?(BerryPlantData) || data.planted?
            mulch_id = data.mulch_id
            propagation_chance = Settings::BERRY_MULCHES_IMPACTING_PROPAGATION[mulch_id] || Settings::BERRY_BASE_PROPAGATION_CHANCE
            next if propagation_chance <= 0 || rand(1000) >= propagation_chance
            data.plant(dropped_berries.sample)
            $stats.berries_propagated ||= 0
            $stats.berries_propagated += 1
        end
    end

    def checkPreferredWeather
        return true if @exposed_to_preferred_weather 
        return false if !@preferred_weather || @growth_stage <= 1 || @growth_stage >= 5 
        return true if $game_screen && @preferred_weather.include?($game_screen.weather_type)
        return false
    end
end

#===============================================================================
# GameStats
#===============================================================================

class GameStats
    attr_accessor :mutated_berries_picked
    attr_accessor :berries_propagated

    alias tdw_berry_improvements_stats_init initialize
    def initialize
        tdw_berry_improvements_stats_init
        @mutated_berries_picked = 0
        @berries_propagated = 0
    end
end

#===============================================================================
# Mutations
#===============================================================================

alias tdw_berry_improvements_berry_plant pbBerryPlant
def pbBerryPlant
    berry_plant = pbMapInterpreter.getVariable
    if berry_plant&.mutated_berry_info
        pbBerryPlantWithMutation
    else
        tdw_berry_improvements_berry_plant
    end
end

def pbBerryPlantWithMutation
    interp = pbMapInterpreter
    this_event = interp.get_self
    berry_plant = interp.getVariable
    berry = berry_plant.berry_id
    # Interact with the event based on its growth
    if berry_plant.grown?
        this_event.turn_up   # Stop the event turning towards the player
        berry_plant.reset if pbPickBerryWithMutation(berry, berry_plant.berry_yield, berry_plant.mutated_berry_info)
        return
    elsif berry_plant.growing?
        berry_name = GameData::Item.get(berry).name
        case berry_plant.growth_stage
        when 1   # X planted
            this_event.turn_down   # Stop the event turning towards the player
            pbMessage(_INTL("A {1} was planted here.", berry_name))
        when 2   # X sprouted
            this_event.turn_down   # Stop the event turning towards the player
            pbMessage(_INTL("The {1} has sprouted.", berry_name))
        when 3   # X taller
            this_event.turn_left   # Stop the event turning towards the player
            pbMessage(_INTL("The {1} plant is growing bigger.", berry_name))
        else     # X flowering
            this_event.turn_right   # Stop the event turning towards the player
            mutation_comment = Settings::BERRY_PLANT_BLOOMING_COMMENT
            if Settings::NEW_BERRY_PLANTS
                pbMessage(_INTL("This {1} plant is in bloom!", berry_name))
            else
                case berry_plant.watering_count
                when 4
                    pbMessage(_INTL("This {1} plant is in fabulous bloom!", berry_name))
                when 3
                    pbMessage(_INTL("This {1} plant is blooming very beautifully!", berry_name))
                when 2
                    pbMessage(_INTL("This {1} plant is blooming prettily!", berry_name))
                when 1
                    pbMessage(_INTL("This {1} plant is blooming cutely!", berry_name))
                else
                    pbMessage(_INTL("This {1} plant is in bloom!", berry_name))
                end
            end
            pbMessage(mutation_comment) if mutation_comment
        end
        # Water the growing plant
        GameData::BerryPlant::WATERING_CANS.each do |item|
            next if !$bag.has?(item)
            break if !pbConfirmMessage(_INTL("Want to sprinkle some water with the {1}?", GameData::Item.get(item).name))
            berry_plant.water
            pbMessage(_INTL("{1} watered the plant.\\wtnp[40]", $player.name))
            if Settings::NEW_BERRY_PLANTS
            pbMessage(_INTL("There! All happy!"))
            else
            pbMessage(_INTL("The plant seemed to be delighted."))
            end
            break
        end
        return
    end
end

def pbPickBerryWithMutation(berry, qty = 1, mutation_info)
    berry = GameData::Item.get(berry)
    mut_berry = GameData::Item.get(mutation_info[0])
    mut_berry_qty = mutation_info[1]
    mut_berry_qty -= 1 while qty - mut_berry_qty < 1
    berry_name = (qty > 1) ? berry.name_plural : berry.name
    mut_berry_name = (mut_berry_qty > 1) ? mut_berry.name_plural : mut_berry.name
    if qty > 1 && mut_berry_qty > 1
      message = _INTL("There are {1} \\c[1]{2}\\c[0] and {3} \\c[1]{4}\\c[0]! \1Want to pick them?", qty, berry_name, mut_berry_qty, mut_berry_name)
    elsif qty > 1
      message = _INTL("There are {1} \\c[1]{2}\\c[0] and 1 \\c[1]{3}\\c[0]! \1Want to pick them?", qty, berry_name, mut_berry_name)
    elsif mut_berry_qty > 1
      message = _INTL("There is 1 \\c[1]{1}\\c[0] and {2} \\c[1]{3}\\c[0]! \1Want to pick them?", berry_name, mut_berry_qty, mut_berry_name)
    else
      message = _INTL("There is 1 \\c[1]{1}\\c[0] and 1 \\c[1]{2}\\c[0]! \1Want to pick them?", berry_name, mut_berry_name)
    end
    return false if !pbConfirmMessage(message)
    if !$bag.can_add?(berry, qty) || !$bag.can_add?(mut_berry, mut_berry_qty)
      pbMessage(_INTL("Too bad...\nThe Bag is full..."))
      return false
    end
    $stats.berry_plants_picked += 1
    $stats.mutated_berries_picked ||= 0
    $stats.mutated_berries_picked += mut_berry_qty
    if qty + mut_berry_qty >= GameData::BerryPlant.get(berry.id).maximum_yield
      $stats.max_yield_berry_plants += 1
    end
    $bag.add(berry, qty)
    $bag.add(mut_berry, mut_berry_qty)
    if qty > 1 && mut_berry_qty > 1
        pbMessage(_INTL("\\me[Berry get]You picked the {1} \\c[1]{2}\\c[0] and {3} \\c[1]{4}\\c[0].\\wtnp[30]", qty, berry_name, mut_berry_qty, mut_berry_name))
    elsif qty > 1
        pbMessage(_INTL("\\me[Berry get]You picked the {1} \\c[1]{2}\\c[0] and \\c[1]{3}\\c[0].\\wtnp[30]", qty, berry_name, mut_berry_name))
    elsif mut_berry_qty > 1
        pbMessage(_INTL("\\me[Berry get]You picked the \\c[1]{1}\\c[0] and {2} \\c[1]{3}\\c[0].\\wtnp[30]", berry_name, mut_berry_qty, mut_berry_name))
    else
        pbMessage(_INTL("\\me[Berry get]You picked the \\c[1]{1}\\c[0] and \\c[1]{2}\\c[0].\\wtnp[30]", berry_name, mut_berry_name))
    end
    pocket = berry.pocket
    pbMessage(_INTL("{1} put them in the <icon=bagPocket{2}>\\c[1]{3}\\c[0] Pocket.\1", $player.name, pocket, PokemonBag.pocket_names[pocket - 1]))
    if Settings::NEW_BERRY_PLANTS
      pbMessage(_INTL("The soil returned to its soft and earthy state."))
    else
      pbMessage(_INTL("The soil returned to its soft and loamy state."))
    end
    this_event = pbMapInterpreter.get_self
    pbSetSelfSwitch(this_event.id, "A", true)
    return true
end

class PokemonGlobalMetadata
    attr_accessor :berry_plant_mutation_parents

    alias tdw_berry_plant_global_init initialize
    def initialize
        tdw_berry_plant_global_init
        compilePlantMutationParents
    end

    def compilePlantMutationParents
        @berry_plant_mutation_parents = []
        Settings::BERRY_MUTATION_POSSIBILITIES.each { |key| 
            @berry_plant_mutation_parents.push(key[0][0]) if !@berry_plant_mutation_parents.include?(key[0][0])
            @berry_plant_mutation_parents.push(key[0][1]) if !@berry_plant_mutation_parents.include?(key[0][1])
        }
    end

end

#===============================================================================
# Town Map
#===============================================================================

def pbForceUpdateAllBerryPlants(mapOnly: false, region: -1, returnArray: false)
    array = []
    $PokemonGlobal.eventvars.each do |info|
        plant = info[1]
        next if !plant.is_a?(BerryPlantData)
        Console.echo_warn _INTL("BerryPlant Event #{info[0][1]} on map #{pbGetBasicMapNameFromId(info[0][0])}[#{info[0][0]}] has no map(region,x,y) defined.") if plant.town_map_location.nil?
        next if mapOnly && plant.town_map_location.nil?
        next if region >= 0 && plant.town_map_location[0] != region
        plant.town_map_checking = true
        plant.update
        plant.town_map_checking = nil
        array.push(plant) if plant.planted?
    end
    return returnArray ? array : nil
end

class PokemonRegionMap_Scene
    def allowShowingBerries
        return false if @wallmap
        return Settings::SHOW_BERRIES_ON_MAP_SWITCH_ID <= 0 || $game_switches[Settings::SHOW_BERRIES_ON_MAP_SWITCH_ID]
    end
        
    if PluginManager.installed?("Arcky's Region Map") 
        def berryModeID
            return 3 if PluginManager.installed?("Arcky's Region Map","1.2") 
            return 0
        end
        
        alias tdw_berry_improvements_map_add addFlyIconSprites
        def addFlyIconSprites
            tdw_berry_improvements_map_add
            addBerryIconSprites if allowShowingBerries
        end

        alias tdw_berry_improvements_map_refresh refreshFlyScreen
        def refreshFlyScreen
            tdw_berry_improvements_map_refresh
            refreshBerryScreen if allowShowingBerries
        end

        def addBerryIconSprites
            if !@spritesMap["BerryIcons"]
                @berryIcons = {}
                regionID = -1
                if @region >= 0 && @playerPos && @region != @playerPos[0]
                    regionID = @region
                elsif @playerPos
                    regionID = @playerPos[0]
                end
                berryPlants = pbForceUpdateAllBerryPlants(mapOnly: true, region: regionID, returnArray: true)
                berryPlants.each do |plant|
                    img = 0
                    if plant.grown? && Settings::BERRIES_ON_MAP_SHOW_READY
                        img = 2
                    elsif plant.moisture_stage == 0 && Settings::BERRIES_ON_MAP_SHOW_NEED_WATER
                        img = 1
                    end
                    if @berryIcons[plant.town_map_location]
                        @berryIcons[plant.town_map_location] = img if img > @berryIcons[plant.town_map_location]
                    else
                        @berryIcons[plant.town_map_location] = img
                    end
                end
                @spritesMap["BerryIcons"] = BitmapSprite.new(@mapWidth, @mapHeigth, @viewportMap)
                @spritesMap["BerryIcons"].x = @spritesMap["map"].x
                @spritesMap["BerryIcons"].y = @spritesMap["map"].y
                @spritesMap["BerryIcons"].z = 59
                @spritesMap["BerryIcons"].visible = @mode == berryModeID
            end
            @berryIcons.each { |key, value|
                conversion = {0 => "mapBerry", 1 => "mapBerryDry", 2 => "mapBerryReady"}
                pbDrawImagePositions(@spritesMap["BerryIcons"].bitmap,
                  [["Graphics/Pictures/Berry Improvements/#{conversion[value]}", pointXtoScreenX(key[1]), pointYtoScreenY(key[2])]])
            }
        end

        def refreshBerryScreen
            @spritesMap["BerryIcons"].visible = @mode == berryModeID
        end
    else
        alias tdw_berry_improvements_map_fy_refresh refresh_fly_screen
        def refresh_fly_screen
            tdw_berry_improvements_map_fy_refresh
            refresh_berry_screen if allowShowingBerries
        end

        def add_berry_icon_sprites
            regionID = -1
            playerpos = ($game_map.metadata) ? $game_map.metadata.town_map_position : nil
            if @region >= 0 && playerpos && @region != playerpos[0]
                regionID = @region
            elsif playerpos
                regionID = playerpos[0]
            end
            berryIcons = {}
            berryPlants = pbForceUpdateAllBerryPlants(mapOnly: true, region: regionID, returnArray: true)
            berryPlants.each do |plant|
                img = 0
                if plant.grown? && Settings::BERRIES_ON_MAP_SHOW_READY
                    img = 2
                elsif plant.moisture_stage == 0 && Settings::BERRIES_ON_MAP_SHOW_NEED_WATER
                    img = 1
                end
                if berryIcons[plant.town_map_location]
                    berryIcons[plant.town_map_location] = img if img > berryIcons[plant.town_map_location]
                else
                    berryIcons[plant.town_map_location] = img
                end
            end
            k = 0
            berryIcons.each { |key, value|
                conversion = {0 => "mapBerry", 1 => "mapBerryDry", 2 => "mapBerryReady"}
                @sprites["berry#{k}"] = IconSprite.new(0, 0, @viewport)
                @sprites["berry#{k}"].setBitmap(pbGetBerryMapIcon(conversion[value]))
                @sprites["berry#{k}"].x        = point_x_to_screen_x(key[1])
                @sprites["berry#{k}"].y        = point_y_to_screen_y(key[2])
                @sprites["berry#{k}"].visible  = @mode == 0
                k += 1
            }
            @sprites.each { |key, sprite|
                next if ["background","map","map2","mapbottom"].include?(key)
                next if key.include?("berry")
                sprite.z += 1
            }
        end

        def refresh_berry_screen
            return if @fly_map || @wallmap
            add_berry_icon_sprites if !@sprites["berry0"]
            @sprites.each do |key, sprite|
                next if !key.include?("berry")
                sprite.visible = (@mode == 0)
            end
        end
    end

    def pbGetBerryMapIcon(id)
        if Essentials::VERSION.include?("21")
            return "Graphics/UI/Berry Improvements/#{id}"
        else
            return "Graphics/Pictures/Berry Improvements/#{id}"
        end
    end
end

#===============================================================================
# Mulch Graphic
#===============================================================================

EventHandlers.add(:on_new_spriteset_map, :add_berry_plant_mulch_graphic,
    proc { |spriteset, viewport|
      next if Settings::BERRY_JUST_MULCH_GRAPHIC.nil? || Settings::BERRY_JUST_MULCH_GRAPHIC.empty?
      map = spriteset.map
      map.events.each do |event|
        next if !event[1].name[/berryplant/i]
        spriteset.addUserSprite(BerryPlantMulchSprite.new(event[1], map, viewport))
      end
    }
)

class BerryPlantMulchSprite
    def initialize(event, map, viewport = nil)
        @event          = event
        @map            = map
        @mulch          = false
        @sprite         = IconSprite.new(0, 0, viewport)
        @sprite.ox      = 16
        @sprite.oy      = 24
        @disposed       = false
        update_graphic
    end
  
    def dispose
        @sprite.dispose
        @map      = nil
        @event    = nil
        @disposed = true
    end
  
    def disposed?
        return @disposed
    end
  
    def update_graphic
        if @mulch  
            @sprite.setBitmap("Graphics/Characters/#{Settings::BERRY_JUST_MULCH_GRAPHIC}")
        else
            @sprite.setBitmap("") 
        end
    end
  
    def update
        return if !@sprite || !@event
        cur_mulch = @mulch
        berry_plant = @event.variable
        return if !berry_plant.is_a?(BerryPlantData)
        if berry_plant.planted? || !berry_plant.mulch_id
            @mulch = false
        else
            @mulch = true
        end
        update_graphic if cur_mulch != @mulch
        @sprite.update
        @sprite.x      = ScreenPosHelper.pbScreenX(@event)
        @sprite.y      = ScreenPosHelper.pbScreenY(@event)
        @sprite.zoom_x = ScreenPosHelper.pbScreenZoomX(@event)
        @sprite.zoom_y = @sprite.zoom_x
        pbDayNightTint(@sprite)
    end
end

#===============================================================================
# Preferred Weather check
#===============================================================================

def pbBerryPreferredWeatherEnabled?
    return PluginManager.installed?("TDW Berry Core and Dex") && Settings::BERRY_PREFERRED_WEATHER_YIELD > 0
end