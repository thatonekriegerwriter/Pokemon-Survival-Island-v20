class FancyCamera
  # Default camera speed (Default: 1)
  DEFAULT_SPEED = 1

  # Increase camera speed when running (Default: true)
  INCREASE_WHEN_RUNNING = true
  
  # Override Scroll Map event commands (Default: true)
  OVERRIDE_SCROLL_MAP = true
end
