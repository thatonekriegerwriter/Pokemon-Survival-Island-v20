# Watch in the Pokegear Menu
This script is for Pokémon Essentials. It add a watch in the Pokégear menu.

## Screens
![](Screens/gif.gif)
![](Screens/screen.png)

## Installation
Follow the [Script](/Script.rb) instructions. The sample script files are in [Files folder](/Files).